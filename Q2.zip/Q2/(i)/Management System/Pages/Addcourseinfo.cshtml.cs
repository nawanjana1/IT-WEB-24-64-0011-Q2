using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Management_System.Pages
{
    public class AddcourseinfoModel : PageModel
    {
        [BindProperty]
        public Course NewCourse { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // TODO: Add code here to save the course to the database

            return RedirectToPage("/Index"); // Redirect after successful form submission
        }
    }
    public class Course
    {
        public int Id { get; set; }

        public string CourseName { get; set; }

        public string Description { get; set; }

        public int Credits { get; set; }
    }
}
