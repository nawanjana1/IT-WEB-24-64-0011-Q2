using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using Management_System.models;

namespace Management_System.Pages
{
    public class StudentinformationModel : PageModel
    {
        // This simulates your student repository or data source.
        public List<Student> Students { get; set; } = new List<Student>();

    
        
    }
}
