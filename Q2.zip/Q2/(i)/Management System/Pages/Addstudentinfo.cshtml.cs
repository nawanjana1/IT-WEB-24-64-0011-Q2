using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Management_System.Pages
{
    public class Index1Model : PageModel
    {
        [BindProperty]
        public Student NewStudent { get; set; }

        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            // TODO: Add code here to save the student to the database

            return RedirectToPage("/Index"); // Redirect after successful form submission
        }
        public class Student
        {
            public int Id { get; set; }

            public string FirstName { get; set; }

            public string LastName { get; set; }

            public DateTime DateOfBirth { get; set; }
        }
    }
}
