select * from Students;
select * from Courses;